from db.base_model import BaseModel
from django.db import models


# Create your models here.
# 使用redis实现购物车的功能
#
#
# class CartInfo(BaseModel):
#
#     class Meta:
#         verbose_name = '购物车商品信息'
#         verbose_name_plural = verbose_name
